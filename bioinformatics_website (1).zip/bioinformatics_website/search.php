<?php include 'header.php'; ?>
<h2>Search Nucleotide Sequences</h2>
<form action="process.php" method="post">
    <label for="searchTerm">Search:</label>
    <input type="text" id="searchTerm" name="searchTerm">
    <input type="submit" name="search" value="Search">
    <input type="submit" name="viewAll" value="View All">
</form>
<?php include 'footer.php'; ?>


