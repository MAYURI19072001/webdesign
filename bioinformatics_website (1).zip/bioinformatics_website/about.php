<?php include 'header.php'; ?>
<h2>About Us</h2>
<p>This website aims to provide comprehensive resources related to nucleotide sequences.</p>
<?php include 'footer.php'; ?>
