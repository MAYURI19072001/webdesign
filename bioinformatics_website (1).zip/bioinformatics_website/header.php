<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nucleotide Sequences</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<header>
    <h1>Nucleotide Sequences Website</h1>
    <nav>
        <a href="index.php">Home</a>
        <a href="about.php">About</a>
        <a href="search.php">Search</a>
        <a href="contact.php">Contact</a>
        <a href="help.php">Help</a>
    </nav>
</header>
<main>
