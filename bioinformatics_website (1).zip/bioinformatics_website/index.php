<?php include 'header.php'; ?>
<h2>Welcome to Nucleotide Sequences</h2>
<p>This website provides tools and information about nucleotide sequences.</p>
<?php include 'footer.php'; ?>
