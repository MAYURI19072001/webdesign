<?php include 'header.php'; ?>
<h2>Help</h2>
<p>For assistance, refer to our FAQs or contact support.</p>
<?php include 'footer.php'; ?>
