<?php
// process.php

// Check if the search form is submitted
if (isset($_POST['search'])) {
    $searchTerm = $_POST['searchTerm'];
    $data = [];
    
    // Open the CSV file
    if (($handle = fopen("sequences.csv", "r")) !== FALSE) {
        // Get the header row
        $headers = fgetcsv($handle);
        
        // Read the data rows
        while (($row = fgetcsv($handle)) !== FALSE) {
            // Create an associative array for each row
            $data[] = array_combine($headers, $row);
        }
        fclose($handle);
    }
    
    // Filter results based on search term (case-insensitive)
    $filteredResults = array_filter($data, function($row) use ($searchTerm) {
        return stripos($row['ACCESSION ID'], $searchTerm) !== FALSE || 
               stripos($row['SOURCE ORGANISM'], $searchTerm) !== FALSE;
    });
    
    // Display results
    if (!empty($filteredResults)) {
        foreach ($filteredResults as $result) {
            echo "<div>";
            echo "<p><strong>Accession ID:</strong> {$result['ACCESSION ID']}</p>";
            echo "<p><strong>Source Organism:</strong> {$result['SOURCE ORGANISM']}</p>";
            echo "<p><strong>Length:</strong> {$result['LENGTH']}</p>";
            echo "<p><strong>Mol-Type:</strong> {$result['MOL-TYPE']}</p>";
            echo "<p><strong>Topology:</strong> {$result['TOPOLOGY']}</p>";
            echo "<p><strong>Division:</strong> {$result['DIVISION']}</p>";
            echo "<p><strong>Sequence:</strong><br>{$result['SEQUENCE IN FASTA']}</p>";
            echo "</div><hr>";
        }
    } else {
        echo "<p>No results found for '{$searchTerm}'.</p>";
    }
} else {
    echo "<p>No search term provided.</p>";
}
?>

<?php
// process.php

// Initialize data array
$data = [];

// Open the CSV file
if (($handle = fopen("sequences.csv", "r")) !== FALSE) {
    // Get the header row
    $headers = fgetcsv($handle);
    
    // Read the data rows
    while (($row = fgetcsv($handle)) !== FALSE) {
        // Create an associative array for each row
        $data[] = array_combine($headers, $row);
    }
    fclose($handle);
}
