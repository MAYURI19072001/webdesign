<?php include 'header.php'; ?>
<h2>Contact Us</h2>
<p>If you have any questions, please contact us at <a href="mailto:info@example.com">info@example.com</a>.</p>
<?php include 'footer.php'; ?>
