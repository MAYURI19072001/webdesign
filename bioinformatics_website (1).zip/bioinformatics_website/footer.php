</main>
<footer>
    <p>&copy; 2024 Nucleotide Sequences Website</p>
</footer>
</body>
</html>
